package com.example.lgpc.waterqualiltydata;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Date;

public class MainActivity extends AppCompatActivity {

    private EditText etSampleId, etTemp;
    private TextView tvDate, tvTime;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        long now = System.currentTimeMillis();
        Date date = new Date(now);
        SimpleDateFormat sdfDate = new SimpleDateFormat("dd/MM/yyyy");
        String formatDate = sdfDate.format(date);

        Date time = new Date(now);
        SimpleDateFormat sdfTime = new SimpleDateFormat("HH:mm");
        String formatTime = sdfTime.format(time);

        tvDate = findViewById(R.id.textDate);
        tvTime = findViewById(R.id.textTime);

        etSampleId = findViewById(R.id.editSampleId);
        etTemp = findViewById(R.id.editTemp);

        tvDate.setText(formatDate);
        tvTime.setText(formatTime);
        //etSampleId.requestFocus();
        etSampleId.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((EditText)v).setInputType(EditorInfo.TYPE_CLASS_TEXT);
                ((EditText)v).requestFocus();
                ((EditText)v).setCursorVisible(true);
            }
        });
        etTemp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((EditText)v).setInputType(EditorInfo.TYPE_NUMBER_FLAG_SIGNED);
                ((EditText)v).requestFocus();
                ((EditText)v).setCursorVisible(true);
            }
        });

    }
}
